# RSVP Movies: SQL Strategy Analysis

SQL analysis of an IMDB-scale relational movie database, turned into a genre, talent, and production-partner strategy for a fictional production house.

**[Read the full write-up →](https://portfolio-bijoy-kumar-sarkar.vercel.app/rsvp-movies-analysis.html)**

## Problem

RSVP Movies needs a data-backed answer to what to produce next and who to work with, instead of greenlighting projects on instinct.

## Data

A six-table relational schema — `movie`, `genre`, `ratings`, `names`, `director_mapping`, `role_mapping` — covering roughly 8,000 films and 25,000+ industry people.

## Approach

Query complexity builds across four segments:

1. **Table shape & data quality** — row counts, null checks
2. **Aggregation & filtering** — genre and yearly release volume
3. **Subqueries** — isolating top performers by rating and votes
4. **Multi-table joins** — connecting a movie's genre and rating back to its specific director and cast

## Key Findings

- Drama is the largest genre by volume (4,285 titles), with 1,078 releases in 2019 alone
- Drama, Action, and Thriller are the consistent top three genres
- Different production partners and talent make sense depending on whether the goal is regional, global, or multilingual reach — a single blanket recommendation would have missed this

## Output

A structured strategic recommendation plan (`Strategic_Recommendation_Plan.pdf`) covering genre focus, production partnerships, talent shortlist, and an immediate/mid-term/long-term roadmap — translating query results into decisions a production house could actually act on.

## Tools

MySQL · SQL (joins, subqueries, aggregation, window-style analysis)

## Files

- `rsvp_movies_queries.sql` — full query set, questions and answers
- `Strategic_Recommendation_Plan.pdf` — the business-facing output
