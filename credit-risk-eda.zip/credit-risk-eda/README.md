# Credit Risk EDA

Exploratory data analysis on a 300,000+ row consumer loan dataset to identify the strongest drivers of default — the kind of insight that could feed a lightweight risk-scoring rule for underwriting.

**[Read the full write-up →](https://portfolio-bijoy-kumar-sarkar.vercel.app/credit-risk-eda.html)**

## Problem

A lending company makes two kinds of costly mistakes: rejecting applicants who would have repaid, and approving applicants who default. This project analyzes historical application data to find which applicant and loan characteristics actually separate defaulters from reliable borrowers.

## Data

Two linked tables — current applications (~307,500 rows) and previous applications (~1.67M rows) — with applicant demographics, income, credit amount, and external credit bureau scores.

## Approach

- **Cleaning:** column-specific missing-value strategy (mean/median where distributions were tight, mode for count-like fields, row deletion only where it cost under 1% of the data)
- **Outlier handling** on income, credit amount, and annuity before any comparison
- **Feature engineering:** derived age and employment-tenure fields from raw day-counts; binned age, income, credit amount, and external score into comparable groups
- **Analysis:** univariate → segmented univariate → bivariate, across both datasets, then merged to test whether prior loan history predicts current risk

## Key Findings

- Younger applicants default at a meaningfully higher rate than senior citizens
- The external credit bureau score was the cleanest single predictor of default in the dataset
- Applicants previously refused a loan were more likely to default on their current one
- Income alone was a weak, sometimes counterintuitive, risk signal

## Tools

Python · Pandas · NumPy · Matplotlib · Seaborn · Jupyter

## Files

- `credit_risk_eda.ipynb` — full analysis notebook
- `Credit_EDA_case_study.pdf` — original case study brief
